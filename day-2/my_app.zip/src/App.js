import React from 'react';
import './App.css';
import Person from './Person/Person'

function App() {
  return (
    <div className="App">
      <h1>React App</h1>
      <Person name='Ankush' age='28'/>
      <Person name='Ankush' age='28'/>
      <Person name='Ankush' age='28'/>
    </div>
  );
  //return React.createElement('div',{className:'App'},React.createElement('h1',null,'Hello I am Amol'));
}

export default App;
