import React, { Component } from 'react';

class person extends Component{
    render(){
        return(
            <p>I am {this.props.name} and my age is {this.props.age}</p>
        )
    }
}
/*const person = (props) => {
    return (
        <p>I am {props.name} and my age is {props.age}</p>
    )
}*/

export default person;