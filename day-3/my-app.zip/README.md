#Steps to run this project:
	#1. npm install
	#2. npm start

#Note: you should have node and create react app installed.