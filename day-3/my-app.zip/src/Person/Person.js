import React, { Component } from 'react';

/*class person extends Component{
    render(){
        return(
            <p>I am {this.props.name} and my age is {this.props.age}</p>
        )
    }
}*/
const person = (props) => {
    return (
        <div>
            <p>I am {props.name} and my age is {props.age}</p>
            <p>{props.children}</p>
        </div>
    )
}

export default person;