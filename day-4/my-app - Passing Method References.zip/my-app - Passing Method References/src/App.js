import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person'

class App extends Component {
  state = {
    persons : [
      {name : 'Ankush', age : '27'},
      {name : 'Amol', age : '28'},
      {name : 'Saurabh', age : '28'},
    ],
    otherPerson: 'xyz'
  }

  switchNameHandler = (newName) => {
    console.log('was clicked');
    //this.state.persons[0] = 'Majahar';
    this.setState({
      persons : [
        {name : newName, age : '27'},
        {name : 'Amol', age : '28'},
        {name : 'Saurabh', age : '28'},
      ]
    });
  }

  render(){
    return (
      <div className="App">
        <h1><span role="img" aria-labelledby="cool" >&#128526;</span>React App<span role="img" aria-labelledby="cool" >&#128526;</span></h1>
        <button className="button" onClick={() => this.switchNameHandler('Test!')}>Switch Name</button>
        <Person name={this.state.persons[0].name}
                age={this.state.persons[0].age}/>
        <Person name={this.state.persons[1].name} 
                age={this.state.persons[1].age}
                click={this.switchNameHandler.bind(this,'Test!!!!')}>
                My Hobbie is playing Cricket
        </Person>
        <Person name={this.state.persons[2].name} 
                age={this.state.persons[2].age}/>
      </div>
    );
  }
}
/*function App() {
  return (
    <div className="App">
      <h1>React App</h1>
      <Person name='Ankush' age='27'/>
      <Person name='Amol' age='28'>My Hobbie is playing Cricket</Person>
      <Person name='Majahar' age='28'/>
    </div>
  );
  //return React.createElement('div',{className:'App'},React.createElement('h1',null,'Hello I am Amol'));
}*/

export default App;
