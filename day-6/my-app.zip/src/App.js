import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person'

class App extends Component {
  state = {
    persons: [
      { name: 'Ankush', age: '27' },
      { name: 'Amol', age: '28' },
      { name: 'Saurabh', age: '28' },
      { name: 'Sagar', age: '29' }
    ],
    otherPerson: 'xyz'
  }


  nameChangedHadnler = (event) => {
    this.setState({
      persons: [
        { name: 'Kirti', age: '27' },
        { name: event.target.value, age: '28' },
        { name: 'Saurabh', age: '28' },
        { name: 'Sagar', age: '29' }
      ]
    });
  }

  togglePersonHandler = (event) => {
    const doesShowPersons = this.state.showPersons;
    this.setState({
      showPersons: !doesShowPersons 
    });
  }

  render() {
    const style = {
      backgroundColor: '#008CBA',
      border: 'none',
      color: 'white',
      padding: '10px 25px',
      textAlign: 'center',
      textDecoration: 'none',
      display: 'inline-block',
      fontSize: '16px',
      margin: '4px 2px',
      cursor: 'pointer'
    }


    let persons = null;
    if (this.state.showPersons) {
      persons = (
        <div>
          {this.state.persons.map(person => {
              return <Person
                name={person.name}
                age={person.age}
              />
          })}
        </div>
      )
    }

    return (
      <div className="App">
        <h1><span role="img" aria-labelledby="cool" >&#128526;</span>React App<span role="img" aria-labelledby="cool" >&#128526;</span></h1>
        <button style={style} onClick={this.togglePersonHandler}>Toggle Persons</button>
       { persons }
      </div>
    );
  }
}
/*function App() {
  return (
    <div className="App">
      <h1>React App</h1>
      <Person name='Ankush' age='27'/>
      <Person name='Amol' age='28'>My Hobbie is playing Cricket</Person>
      <Person name='Majahar' age='28'/>
    </div>
  );
  //return React.createElement('div',{className:'App'},React.createElement('h1',null,'Hello I am Amol'));
}*/

export default App;
