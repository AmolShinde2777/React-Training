import React from 'react';

const Test = (props) => {
    return (
        <div>
            <h1>Amol Shinde</h1>
            <p>{props.children}</p>
        </div>
    )
}

export default Test;